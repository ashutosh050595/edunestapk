#!/bin/bash

# EduNest APK Build Script
# Sacred Heart School Koderma

set -e  # Exit on error

echo "======================================"
echo "   EduNest APK Build Script"
echo "   Sacred Heart School Koderma"
echo "======================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check prerequisites
echo -e "${BLUE}Checking prerequisites...${NC}"

# Check Java
if ! command -v java &> /dev/null; then
    echo -e "${RED}✗ Java not found. Please install JDK 17 or later.${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Java found: $(java -version 2>&1 | head -n 1)${NC}"

# Check Android SDK
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
    echo -e "${RED}✗ Android SDK not found.${NC}"
    echo "Please set ANDROID_HOME or ANDROID_SDK_ROOT environment variable."
    echo "Example: export ANDROID_HOME=/path/to/Android/sdk"
    exit 1
fi
echo -e "${GREEN}✓ Android SDK found${NC}"

# Navigate to android directory
cd android

echo ""
echo -e "${BLUE}Cleaning previous builds...${NC}"
./gradlew clean

echo ""
echo -e "${BLUE}Building APK...${NC}"

# Ask user which build type
echo ""
echo "Select build type:"
echo "1) Debug APK (unsigned, for testing)"
echo "2) Release APK (unsigned)"
echo "3) Release APK (signed - requires keystore)"
read -p "Enter choice [1-3]: " choice

case $choice in
    1)
        echo -e "${BLUE}Building debug APK...${NC}"
        ./gradlew assembleDebug
        APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
        ;;
    2)
        echo -e "${BLUE}Building release APK (unsigned)...${NC}"
        ./gradlew assembleRelease
        APK_PATH="app/build/outputs/apk/release/app-release-unsigned.apk"
        ;;
    3)
        echo -e "${BLUE}Building signed release APK...${NC}"
        if [ ! -f "key.properties" ]; then
            echo -e "${RED}✗ key.properties not found.${NC}"
            echo "Please create key.properties file first."
            echo "See BUILD_APK_README.md for instructions."
            exit 1
        fi
        ./gradlew assembleRelease
        APK_PATH="app/build/outputs/apk/release/app-release.apk"
        ;;
    *)
        echo -e "${RED}Invalid choice${NC}"
        exit 1
        ;;
esac

echo ""
if [ -f "$APK_PATH" ]; then
    echo -e "${GREEN}======================================"
    echo "   ✓ Build Successful!"
    echo "======================================${NC}"
    echo ""
    echo "APK Location:"
    echo "$(pwd)/$APK_PATH"
    echo ""
    
    # Get APK size
    APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
    echo "APK Size: $APK_SIZE"
    echo ""
    
    # Copy to easy access location
    mkdir -p ../../outputs
    cp "$APK_PATH" ../../outputs/edunest-$(date +%Y%m%d-%H%M%S).apk
    echo -e "${GREEN}✓ APK also copied to: outputs/edunest-$(date +%Y%m%d-%H%M%S).apk${NC}"
    echo ""
    
    echo "Next steps:"
    echo "1. Install on device: adb install $APK_PATH"
    echo "2. Or copy the APK to your device and install manually"
    echo ""
else
    echo -e "${RED}✗ Build failed. Check the error messages above.${NC}"
    exit 1
fi
