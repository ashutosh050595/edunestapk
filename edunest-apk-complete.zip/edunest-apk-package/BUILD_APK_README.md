# EduNest School ERP - Android APK Build Guide

## 📱 About EduNest

**EduNest** is a comprehensive School Management System designed for Sacred Heart School Koderma. This package contains everything needed to build the Android APK with animated EduNest branding.

## ✨ Features Included

- ✅ Complete student admission and records management
- ✅ Daily attendance tracking
- ✅ Fee collection and financial reports
- ✅ Examination management and report cards
- ✅ Library management system
- ✅ Transport management
- ✅ Staff management and payroll
- ✅ Timetable scheduling
- ✅ Notifications system
- ✅ ID card generation
- ✅ Parent/Student portals
- ✅ And many more features...

## 🎨 Branding

The app includes:
- **Animated EduNest logo** with graduation cap icon
- **Custom app icon** in all required resolutions
- **Splash screen** with smooth animations
- **Blue gradient** theme (#1d4ed8 → #2563eb → #3b82f6)
- **Professional UI** with modern design

## 📦 Package Contents

```
School_ERP_Frontend-main/
├── android/              # Complete Android project
│   ├── app/
│   │   └── src/main/
│   │       ├── assets/   # Web assets
│   │       ├── res/      # Icons and resources
│   │       └── AndroidManifest.xml
│   ├── gradlew           # Gradle wrapper
│   └── build.gradle      # Build configuration
├── out/                  # Compiled web application
├── public/
│   └── assets/           # Logo and icons
└── capacitor.config.ts   # Capacitor configuration
```

## 🔧 Prerequisites

Before building the APK, ensure you have:

1. **JDK 17 or later**
   ```bash
   java -version
   ```

2. **Android SDK** (via Android Studio or command-line tools)
   - Android SDK Platform 33 or later
   - Android SDK Build-Tools 33.0.0 or later
   
3. **Android Studio** (recommended) or
   **Command-line tools** with environment variables:
   ```bash
   export ANDROID_HOME=/path/to/Android/sdk
   export PATH=$PATH:$ANDROID_HOME/platform-tools
   export PATH=$PATH:$ANDROID_HOME/tools
   ```

## 🚀 Building the APK

### Method 1: Using Android Studio (Recommended)

1. **Open the project:**
   ```bash
   cd School_ERP_Frontend-main
   ```

2. **Open in Android Studio:**
   - Open Android Studio
   - Select "Open an Existing Project"
   - Navigate to `School_ERP_Frontend-main/android`
   - Click "OK"

3. **Build APK:**
   - Click `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - Wait for the build to complete
   - Click "locate" when the build succeeds
   - The APK will be at: `android/app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Using Gradle Command Line

1. **Navigate to the android directory:**
   ```bash
   cd School_ERP_Frontend-main/android
   ```

2. **Build debug APK:**
   ```bash
   ./gradlew assembleDebug
   ```

3. **Build release APK (unsigned):**
   ```bash
   ./gradlew assembleRelease
   ```

4. **Find the APK:**
   - Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
   - Release APK: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Method 3: Using Capacitor CLI

1. **Install dependencies (if not already done):**
   ```bash
   cd School_ERP_Frontend-main
   npm install
   ```

2. **Sync Capacitor:**
   ```bash
   npx cap sync android
   ```

3. **Open in Android Studio:**
   ```bash
   npx cap open android
   ```

4. **Build APK** using Android Studio (as in Method 1)

## 🔐 Creating a Signed Release APK

For production release, you need to sign the APK:

1. **Generate a keystore:**
   ```bash
   keytool -genkey -v -keystore edunest-release-key.keystore \
     -alias edunest -keyalg RSA -keysize 2048 -validity 10000
   ```

2. **Create `android/key.properties`:**
   ```properties
   storePassword=YOUR_KEYSTORE_PASSWORD
   keyPassword=YOUR_KEY_PASSWORD
   keyAlias=edunest
   storeFile=../edunest-release-key.keystore
   ```

3. **Update `android/app/build.gradle`:**
   Add before the `android` block:
   ```gradle
   def keystoreProperties = new Properties()
   def keystorePropertiesFile = rootProject.file('key.properties')
   if (keystorePropertiesFile.exists()) {
       keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
   }
   ```

   Update the `android` block:
   ```gradle
   android {
       ...
       signingConfigs {
           release {
               keyAlias keystoreProperties['keyAlias']
               keyPassword keystoreProperties['keyPassword']
               storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
               storePassword keystoreProperties['storePassword']
           }
       }
       buildTypes {
           release {
               signingConfig signingConfigs.release
               ...
           }
       }
   }
   ```

4. **Build signed APK:**
   ```bash
   cd android
   ./gradlew assembleRelease
   ```

5. **Find signed APK:**
   `app/build/outputs/apk/release/app-release.apk`

## 📱 Installing the APK

### On Physical Device:

1. **Enable Developer Options:**
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times

2. **Enable USB Debugging:**
   - Settings → Developer Options → USB Debugging

3. **Install via ADB:**
   ```bash
   adb install app-debug.apk
   ```

### Via File Transfer:

1. Copy the APK to your device
2. Open the APK file
3. Tap "Install"
4. Accept permissions

## 🔧 Troubleshooting

### Build Fails:

1. **Clean the build:**
   ```bash
   cd android
   ./gradlew clean
   ./gradlew assembleDebug
   ```

2. **Check Java version:**
   ```bash
   java -version  # Should be 11 or later
   ```

3. **Update Gradle wrapper:**
   ```bash
   cd android
   ./gradlew wrapper --gradle-version=8.0
   ```

### App Crashes:

1. **Check logs:**
   ```bash
   adb logcat | grep -i EduNest
   ```

2. **Clear app data:**
   Settings → Apps → EduNest → Clear Data

### Backend Connection Issues:

The app connects to: `https://school-erp-bay.vercel.app`

To change the backend URL:
1. Edit `capacitor.config.ts`
2. Add server configuration:
   ```typescript
   server: {
     url: 'https://your-backend-url.com',
     cleartext: true
   }
   ```

## 📊 App Information

- **App Name:** EduNest
- **Package Name:** com.sacredheart.edunest
- **Version:** 2.0.0
- **Target SDK:** 33
- **Min SDK:** 22 (Android 5.1+)

## 🎨 Customization

### Change App Icon:
Replace files in `public/assets/`:
- `icon.png` (512x512)
- `icon-192.png` (192x192)
- `icon-96.png` (96x96)
- `icon-72.png` (72x72)
- `icon-48.png` (48x48)

Then copy to Android:
```bash
npm run android:icons
```

### Change App Name:
Edit `android/app/src/main/res/values/strings.xml`:
```xml
<string name="app_name">Your App Name</string>
```

### Change Colors:
Edit `app/globals.css` and update CSS variables

## 📞 Support

- **School:** Sacred Heart School Koderma
- **Developer:** Ashutosh Kumar Gautam
- **Version:** 2.0

## 📄 License

This is proprietary software developed for Sacred Heart School Koderma.

---

**Built with ❤️ for Sacred Heart School Koderma**

*EduNest - Where every student's journey is nurtured*
