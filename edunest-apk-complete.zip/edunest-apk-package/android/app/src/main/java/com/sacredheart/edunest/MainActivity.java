package com.sacredheart.edunest;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
